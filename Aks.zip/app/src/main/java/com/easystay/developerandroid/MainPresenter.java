package com.easystay.developerandroid;

import com.google.gson.JsonObject;


import rx.Subscriber;
import rx.Subscription;
import rx.android.schedulers.AndroidSchedulers;
import rx.schedulers.Schedulers;

/**
 * Created by Aks4125 on 7/11/2017.
 */

public class MainPresenter implements MainContractor.IMainPresenter {

    MainContractor.IMainView mainView;
    WebService webService;
    Subscription mSubscription;

    public MainPresenter(WebService webService) {
        this.webService = webService;
    }

    public void setMainView(MainContractor.IMainView mainView) {
        this.mainView = mainView;
    }


    @Override
    public void subscribe() {

    }

    @Override
    public void apiCall() {
        mainView.showProgress();
        mainView.showMessage("loading" );


        mSubscription = webService.getNearbyBeacons()
                .subscribeOn(Schedulers.io())
                .observeOn(AndroidSchedulers.mainThread())
                .subscribe(new Subscriber<JsonObject>() {
                    @Override
                    public void onCompleted() {

                    }

                    @Override
                    public void onError(Throwable e) {
                        mainView.showMessage("Webservice error");
                        mainView.stopProgress();
                    }

                    @Override
                    public void onNext(JsonObject jsonObject) {
                        mainView.stopProgress();
                        mainView.showMessage("Success" );
                        mainView.processJson(jsonObject);
                    }
                });


    }

    @Override
    public void unsubscribe() {
        if (mSubscription != null && !mSubscription.isUnsubscribed())
            mSubscription.unsubscribe();

        mainView.stopProgress();

    }


}
