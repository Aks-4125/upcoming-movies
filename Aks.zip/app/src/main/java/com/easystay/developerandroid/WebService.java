package com.easystay.developerandroid;

import com.google.gson.JsonObject;

import retrofit2.http.GET;
import retrofit2.http.Query;
import rx.Observable;

public interface WebService {

    @GET("BeaconRestHandler.php")
    Observable<JsonObject> getBeaconDetails(@Query("id") String id);


    @GET("BeaconList.php")
    Observable<JsonObject> getNearbyBeacons();

}
